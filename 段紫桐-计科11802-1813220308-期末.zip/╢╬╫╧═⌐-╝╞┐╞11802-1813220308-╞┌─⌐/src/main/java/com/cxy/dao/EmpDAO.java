package com.cxy.dao;
import com.cxy.entity.Emp;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EmpDAO {
    List<Emp> findAll();
    void save(Emp emp);
    void delete(String id);
    Emp findOne(String id);
    void update(Emp emp);
}
