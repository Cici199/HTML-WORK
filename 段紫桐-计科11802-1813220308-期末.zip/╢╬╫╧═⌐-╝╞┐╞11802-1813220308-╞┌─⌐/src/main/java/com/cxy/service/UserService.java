package com.cxy.service;

import com.cxy.entity.User;
import org.springframework.beans.factory.annotation.Autowired;

public interface UserService {

    //用户注册
    void regster(User user);

    //用户登录
    User login(User user);
}
