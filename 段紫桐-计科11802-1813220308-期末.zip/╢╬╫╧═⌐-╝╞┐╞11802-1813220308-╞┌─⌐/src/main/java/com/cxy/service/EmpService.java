package com.cxy.service;

import java.util.List;
import com.cxy.entity.Emp;

public interface EmpService {
    List<Emp> findAll();
    void save(Emp emp);
    void delete(String id);
    Emp findOne(String id);
    void update(Emp emp);
}
