package com.cxy.entity;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class User {
    private String id;
    private String username;
    private String name;
    private String password;
    private String sex;
    private String status;
    private Date regsterTime;
}
