package com.cxy.dao;

import com.cxy.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Mapper
public interface UserDAO {

    void save(User user);

    User findByUserName(String username);
}
